--!native
--!strict
--!optimize 2

local State = require(script.Parent.Parent.Parent.state)
local Fusion = require(script.Parent.Parent.Parent.Packages.Fusion)

local New = Fusion.New
local Children = Fusion.Children
local Value = Fusion.Value
local Computed = Fusion.Computed
local ForPairs = Fusion.ForPairs

local StudioComponents = script.Parent.Parent.Parent.Components:FindFirstChild("StudioComponents")
local Button = require(StudioComponents.Button)
local MainButton = require(StudioComponents.MainButton)
local Label = require(StudioComponents.Label)
local Slider = require(StudioComponents.Slider)
local VerticalCollapsibleSection = require(StudioComponents.VerticalCollapsibleSection)

local DecalControls = {}

function DecalControls.createDecalControlsUI(services: any, layoutOrder: number?)
	local activeHint = Value("")

	return VerticalCollapsibleSection({
		Text = "🎭 Decal Expressions & Layers",
		Collapsed = not State.activeRigExists:get(),
		LayoutOrder = layoutOrder or 3,
		[Children] = {
			-- Status label
			Label({
				Text = Computed(function()
					local names = State.decalNames:get()
					local count = #names
					if not State.activeRigExists:get() then
						return "Select a character/rig with Decals to animate."
					elseif count == 0 then
						return "No Decals found under the selected Rig."
					else
						return string.format("Detected %d Decal(s) on Rig:", count)
					end
				end),
				LayoutOrder = 1,
			}),

			-- Rescan Button
			New("Frame")({
				Size = UDim2.new(1, 0, 0, 26),
				LayoutOrder = 2,
				BackgroundTransparency = 1,
				[Children] = {
					Button({
						Text = "🔍 Rescan Rig Decals",
						Size = UDim2.new(1, 0, 1, 0),
						Activated = function(): nil
							if services and services.rigManager then
								services.rigManager:scanRigDecals()
							end
							return nil
						end,
						Enabled = Computed(function()
							return State.activeRigExists:get()
						end),
					}),
				},
			}) :: any,

			-- Quick Expression Flipbook Buttons
			Label({
				Text = "Quick Expression Switch (Solo):",
				LayoutOrder = 3,
				Visible = Computed(function()
					return #State.decalNames:get() > 0
				end),
			}),

			New("Frame")({
				Size = UDim2.new(1, 0, 0, 32),
				LayoutOrder = 4,
				BackgroundTransparency = 1,
				Visible = Computed(function()
					return #State.decalNames:get() > 0
				end),
				[Children] = {
					New("UIListLayout")({
						FillDirection = Enum.FillDirection.Horizontal,
						SortOrder = Enum.SortOrder.LayoutOrder,
						Padding = UDim.new(0, 4),
					}),
					ForPairs(State.decalNames, function(index: number, decalName: string)
						local shortLabel = string.gsub(decalName, "Face%.", "F.")
						if shortLabel == decalName then
							shortLabel = string.gsub(decalName, "Face", "F.")
						end

						local btn = Button({
							Text = shortLabel,
							Size = UDim2.new(0, 44, 1, 0),
							LayoutOrder = index,
							Activated = function(): nil
								if services and services.rigManager then
									services.rigManager:soloDecal(decalName)
								end
								return nil
							end,
						})

						return index, btn
					end, Fusion.cleanup),
				},
			}) :: any,

			-- List of individual decal transparency sliders
			New("Frame")({
				Size = UDim2.new(1, 0, 0, 0),
				AutomaticSize = Enum.AutomaticSize.Y,
				LayoutOrder = 5,
				BackgroundTransparency = 1,
				Visible = Computed(function()
					return #State.decalNames:get() > 0
				end),
				[Children] = {
					New("UIListLayout")({
						FillDirection = Enum.FillDirection.Vertical,
						SortOrder = Enum.SortOrder.LayoutOrder,
						Padding = UDim.new(0, 6),
					}),
					ForPairs(State.decalNames, function(index: number, decalName: string)
						local decalVal = Value(0)
						local activeDecals = State.activeDecals:get()
						local decalObj = activeDecals[decalName]
						if decalObj then
							decalVal:set(decalObj.Transparency)
						end

						local itemFrame = New("Frame")({
							Size = UDim2.new(1, 0, 0, 48),
							LayoutOrder = index,
							BackgroundTransparency = 0.9,
							[Children] = {
								New("UIListLayout")({
									FillDirection = Enum.FillDirection.Vertical,
									Padding = UDim.new(0, 2),
								}),
								New("Frame")({
									Size = UDim2.new(1, 0, 0, 20),
									BackgroundTransparency = 1,
									[Children] = {
										Label({
											Text = decalName,
											Size = UDim2.new(0.65, 0, 1, 0),
										}),
										Button({
											Text = "Solo",
											Size = UDim2.new(0.3, 0, 1, 0),
											Position = UDim2.new(0.7, 0, 0, 0),
											Activated = function(): nil
												if services and services.rigManager then
													services.rigManager:soloDecal(decalName)
													decalVal:set(0)
												end
												return nil
											end,
										}),
									},
								}),
								Slider({
									Size = UDim2.new(1, 0, 0, 18),
									Min = 0,
									Max = 1,
									Step = 0.05,
									Value = decalVal,
									OnChange = function(newVal)
										decalVal:set(newVal)
										if services and services.rigManager then
											services.rigManager:setDecalTransparency(decalName, newVal)
										end
									end,
								}),
							},
						})

						return index, itemFrame
					end, Fusion.cleanup),
				},
			}) :: any,
		},
	})
end

return DecalControls
